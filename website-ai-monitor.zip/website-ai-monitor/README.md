# Website AI Monitor

أداة لمراقبة **المواقع التي تملكها أو لديك إذن باختبارها**. في كل دورة تفتح الموقع بمتصفح حقيقي (Playwright/Chromium)، تلتقط Screenshot، تجمع (العنوان، حالة HTTP، وقت التحميل، الأخطاء)، وترسلها إلى Gemini للتحليل، مع لوحة نتائج مباشرة وسجل زمني وتقرير قابل للتصدير.

> الأداة لا تدعم ولا تحتوي على: VPN / Proxy / تغيير IP أو الدولة، ولا توليد مشاهدات أو نقرات، ولا التحايل على الإعلانات أو الإحصائيات. الفاصل الأدنى بين الفحوصات مفروض من الخادم، وتأكيد الملكية إلزامي قبل البدء.

## المميزات
- إدخال الرابط، وعدد الفحوصات (1 / 10 / 50 / 100 / رقم مخصص / **لا نهائي ∞** حتى الضغط على «إيقاف»).
- فاصل انتظار قابل للتعديل (الحد الأدنى `MIN_DELAY_SEC`).
- تحليل Gemini: ماذا يظهر، الأخطاء، جودة التصميم، العناصر المفقودة، الملخص.
- بث مباشر (SSE) للنتائج والسجل، زر إيقاف، تصدير تقرير HTML يحتوي كل اللقطات والنتائج.
- فشل أي فحص يُسجَّل ثم ينتقل للفحص التالي.
- مفتاح Gemini يبقى في الخادم فقط (`GEMINI_API_KEY` أو من الإعدادات).
- واجهة عربية RTL متجاوبة مع الهاتف.

## التشغيل محلياً
المتطلبات: Node.js 18 أو أحدث.

```bash
npm install
npx playwright install --with-deps chromium
cp .env.example .env      # ثم ضع GEMINI_API_KEY (أو أدخله من الإعدادات)
npm start
```
افتح http://localhost:3000

لفحص موقع محلي (localhost) للتجربة ضع `ALLOW_PRIVATE=true` في `.env`.

## النشر على VPS (Ubuntu)
```bash
sudo apt update && sudo apt install -y nginx
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt install -y nodejs
cd /opt && sudo git clone <مشروعك> website-ai-monitor && cd website-ai-monitor
npm install && npx playwright install --with-deps chromium
cp .env.example .env && nano .env     # GEMINI_API_KEY و APP_PASSWORD (إلزامي عند النشر)
sudo npm i -g pm2 && pm2 start server.js --name ai-monitor && pm2 save && pm2 startup
```
إعداد Nginx (مع SSL عبر certbot):
```nginx
server {
  server_name monitor.example.com;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_buffering off;          # مهم للبث المباشر SSE
    proxy_read_timeout 3600s;
  }
}
```
ثم: `sudo certbot --nginx -d monitor.example.com`

## ملاحظة عن InfinityFree
الاستضافة المجانية (InfinityFree) تدعم PHP/MySQL فقط ولا تشغّل Node.js ولا متصفحاً بدون واجهة، لذلك **لا يمكن تشغيل الخادم عليها**. الخيار العملي:

1. شغّل الخادم على VPS (أو أي استضافة Node) مع HTTPS.
2. في `.env` على الخادم ضع: `CORS_ORIGIN=https://nasihuhmindhahab.ct.ws`
3. ارفع محتويات مجلد `public/` فقط إلى `htdocs` في InfinityFree.
4. عدّل `config.js`: `window.API_BASE = "https://monitor.example.com";` (أو أدخله من الإعدادات في الواجهة).

## متغيرات البيئة
| المتغير | الوصف |
|---|---|
| `GEMINI_API_KEY` | مفتاح Gemini |
| `GEMINI_MODEL` | افتراضي `gemini-2.5-flash` |
| `APP_PASSWORD` | كلمة مرور اللوحة |
| `MIN_DELAY_SEC` | أقل فاصل بين الفحوصات (افتراضي 5) |
| `MAX_KEEP` | أقصى عدد نتائج محفوظة للتشغيل الواحد (افتراضي 300) |
| `ALLOW_PRIVATE` | السماح بالشبكات الداخلية |
| `CORS_ORIGIN` | دومين الواجهة إن كانت منفصلة |

## ملاحظات
- اللقطات تُحفظ مؤقتاً في `data/` وتُحذف عند إعادة تشغيل الخادم.
- في الوضع اللانهائي يُحتفظ بآخر `MAX_KEEP` نتيجة فقط لتوفير المساحة.
- تكلفة Gemini تزيد مع كل فحص؛ استخدم فاصلاً مناسباً.
