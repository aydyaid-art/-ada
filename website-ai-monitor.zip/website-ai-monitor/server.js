import express from 'express';
import { chromium } from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import dns from 'node:dns/promises';
import net from 'node:net';
import { fileURLToPath } from 'node:url';

// ---------- تحميل .env (بدون مكتبات إضافية) ----------
const __dirname = path.dirname(fileURLToPath(import.meta.url));
try {
  const raw = await fs.readFile(path.join(__dirname, '.env'), 'utf8');
  for (const line of raw.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !line.trim().startsWith('#') && process.env[m[1]] === undefined) {
      process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  }
} catch { /* لا يوجد ملف .env */ }

const PORT = Number(process.env.PORT || 3000);
const MIN_DELAY = Math.max(1, Number(process.env.MIN_DELAY_SEC || 5));
const MAX_KEEP = Math.max(10, Number(process.env.MAX_KEEP || 300));
const ALLOW_PRIVATE = process.env.ALLOW_PRIVATE === 'true';
const APP_PASSWORD = process.env.APP_PASSWORD || '';
const CORS_ORIGIN = process.env.CORS_ORIGIN || '';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const DATA_DIR = path.join(__dirname, 'data');
const MAX_RUNS = 3;

// ---------- ملفات المحاكاة: الدولة (لغة/منطقة زمنية/موقع) والجهاز ----------
// ملاحظة: هذه محاكاة على مستوى المتصفح فقط (لغة، منطقة زمنية، إحداثيات، جهاز).
// عنوان IP الحقيقي للخادم لا يتغيّر.
const COUNTRIES = {
  IQ: { name: 'العراق', locale: 'ar-IQ', tz: 'Asia/Baghdad', geo: [33.3152, 44.3661] },
  SA: { name: 'السعودية', locale: 'ar-SA', tz: 'Asia/Riyadh', geo: [24.7136, 46.6753] },
  EG: { name: 'مصر', locale: 'ar-EG', tz: 'Africa/Cairo', geo: [30.0444, 31.2357] },
  AE: { name: 'الإمارات', locale: 'ar-AE', tz: 'Asia/Dubai', geo: [25.2048, 55.2708] },
  JO: { name: 'الأردن', locale: 'ar-JO', tz: 'Asia/Amman', geo: [31.9454, 35.9284] },
  MA: { name: 'المغرب', locale: 'ar-MA', tz: 'Africa/Casablanca', geo: [33.5731, -7.5898] },
  TR: { name: 'تركيا', locale: 'tr-TR', tz: 'Europe/Istanbul', geo: [41.0082, 28.9784] },
  US: { name: 'أمريكا', locale: 'en-US', tz: 'America/New_York', geo: [40.7128, -74.006] },
  GB: { name: 'بريطانيا', locale: 'en-GB', tz: 'Europe/London', geo: [51.5072, -0.1276] },
  DE: { name: 'ألمانيا', locale: 'de-DE', tz: 'Europe/Berlin', geo: [52.52, 13.405] },
  FR: { name: 'فرنسا', locale: 'fr-FR', tz: 'Europe/Paris', geo: [48.8566, 2.3522] },
  ES: { name: 'إسبانيا', locale: 'es-ES', tz: 'Europe/Madrid', geo: [40.4168, -3.7038] },
  RU: { name: 'روسيا', locale: 'ru-RU', tz: 'Europe/Moscow', geo: [55.7558, 37.6173] },
  IN: { name: 'الهند', locale: 'en-IN', tz: 'Asia/Kolkata', geo: [28.6139, 77.209] },
  PK: { name: 'باكستان', locale: 'ur-PK', tz: 'Asia/Karachi', geo: [24.8607, 67.0011] },
  ID: { name: 'إندونيسيا', locale: 'id-ID', tz: 'Asia/Jakarta', geo: [-6.2088, 106.8456] },
  BR: { name: 'البرازيل', locale: 'pt-BR', tz: 'America/Sao_Paulo', geo: [-23.5505, -46.6333] },
  JP: { name: 'اليابان', locale: 'ja-JP', tz: 'Asia/Tokyo', geo: [35.6762, 139.6503] }
};
const DEVICES = {
  desktop: { name: 'كمبيوتر', viewport: { width: 1366, height: 768 }, dsf: 1, mobile: false, touch: false,
    ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36' },
  android: { name: 'أندرويد (Pixel)', viewport: { width: 412, height: 915 }, dsf: 2.625, mobile: true, touch: true,
    ua: 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36' },
  'android-small': { name: 'أندرويد شاشة صغيرة', viewport: { width: 360, height: 640 }, dsf: 2, mobile: true, touch: true,
    ua: 'Mozilla/5.0 (Linux; Android 10; SM-A105F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36' },
  iphone: { name: 'آيفون', viewport: { width: 390, height: 844 }, dsf: 3, mobile: true, touch: true,
    ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1' },
  tablet: { name: 'تابلت (iPad)', viewport: { width: 820, height: 1180 }, dsf: 2, mobile: true, touch: true,
    ua: 'Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1' }
};
const MAX_COMBOS = 200;
const UA_TAG = ' WebsiteAIMonitor/1.0'; // يسهّل عليك استبعاد فحوصاتك من إحصائيات موقعك

function buildCombos(countryKeys, deviceKeys) {
  const cs = [...new Set((countryKeys || []).filter((k) => COUNTRIES[k]))];
  const ds = [...new Set((deviceKeys || []).filter((k) => DEVICES[k]))];
  const cList = cs.length ? cs : [null];
  const dList = ds.length ? ds : ['desktop'];
  const out = [];
  for (const c of cList) for (const d of dList) out.push({ country: c, device: d });
  return out.slice(0, MAX_COMBOS);
}
const comboLabel = (c) => `${c.country ? COUNTRIES[c.country].name : 'افتراضي'} · ${DEVICES[c.device].name}`;

let geminiKey = process.env.GEMINI_API_KEY || '';
let keySource = geminiKey ? 'env' : 'none';

await fs.rm(DATA_DIR, { recursive: true, force: true });
await fs.mkdir(DATA_DIR, { recursive: true });

// ---------- أدوات ----------
const runs = new Map();
const nowISO = () => new Date().toISOString();
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function isPrivateIP(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  const l = ip.toLowerCase();
  return l === '::1' || l === '::' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80') || l.startsWith('::ffff:127.') || l.startsWith('::ffff:10.') || l.startsWith('::ffff:192.168.');
}

async function validateTarget(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new Error('الرابط غير صالح'); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('يُسمح فقط بروابط http و https');
  if (!ALLOW_PRIVATE) {
    const addrs = net.isIP(u.hostname) ? [{ address: u.hostname }] : await dns.lookup(u.hostname, { all: true }).catch(() => { throw new Error('تعذر العثور على الدومين'); });
    if (addrs.some((a) => isPrivateIP(a.address))) throw new Error('الشبكات الداخلية غير مسموحة (فعّل ALLOW_PRIVATE=true للتجربة المحلية)');
  }
  return u.toString();
}

function auth(req, res, next) {
  if (!APP_PASSWORD) return next();
  const t = req.get('x-app-password') || req.query.token || '';
  const a = Buffer.from(String(t)), b = Buffer.from(APP_PASSWORD);
  if (a.length === b.length && crypto.timingSafeEqual(a, b)) return next();
  res.status(401).json({ error: 'كلمة المرور مطلوبة أو غير صحيحة' });
}

function log(run, level, msg) {
  const entry = { t: nowISO(), level, msg };
  run.logs.push(entry);
  if (run.logs.length > 1000) run.logs.shift();
  emit(run, 'log', entry);
}
function emit(run, event, data) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const c of run.clients) c.write(payload);
}
const snapshot = (run) => ({
  id: run.id, url: run.url, total: run.total, delaySec: run.delayMs / 1000,
  status: run.status, done: run.done, ok: run.okCount, failed: run.failCount,
  startedAt: run.startedAt, finishedAt: run.finishedAt || null,
  light: run.light, byProfile: aggTable(run), topErrors: topErrors(run), summary: run.finalAnalysis || ''
});

// ---------- إحصاءات مجمّعة (للفحص الواسع) ----------
function recordAgg(run, r) {
  const a = run.agg.get(r.profile) || { profile: r.profile, n: 0, ok: 0, fail: 0, warn: 0, loads: [] };
  a.n++; r.ok ? a.ok++ : a.fail++;
  if (r.errors.length) a.warn++;
  if (r.loadMs != null && r.ok) { a.loads.push(r.loadMs); if (a.loads.length > 500) a.loads.shift(); }
  run.agg.set(r.profile, a);
  for (const e of r.errors) {
    const k = e.slice(0, 140);
    run.errCounts.set(k, (run.errCounts.get(k) || 0) + 1);
  }
  if (r.error) { const k = 'فشل فتح: ' + r.error.slice(0, 120); run.errCounts.set(k, (run.errCounts.get(k) || 0) + 1); }
}
const pct = (arr, p) => { if (!arr.length) return null; const s = [...arr].sort((x, y) => x - y); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
function aggTable(run) {
  return [...run.agg.values()].map((a) => ({
    profile: a.profile, n: a.n, ok: a.ok, fail: a.fail, warn: a.warn,
    avg: a.loads.length ? Math.round(a.loads.reduce((x, y) => x + y, 0) / a.loads.length) : null,
    p95: pct(a.loads, 0.95)
  })).sort((x, y) => (y.fail + y.warn) / y.n - (x.fail + x.warn) / x.n);
}
const topErrors = (run) => [...run.errCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 15).map(([msg, count]) => ({ msg, count }));

// ---------- Gemini ----------
async function analyzeWithGemini(shotBuf, info) {
  if (!geminiKey) return 'لم يتم تعيين مفتاح Gemini. أضفه من الإعدادات أو من ملف .env';
  const prompt = `أنت مهندس جودة (QA) لمواقع الويب. حلّل لقطة الشاشة المرفقة والمعلومات التقنية التالية، وأجب بالعربية وبإيجاز:

المعلومات التقنية:
- الرابط: ${info.url}
- الملف المحاكى: ${info.profile}
- لغة الصفحة المصرّح بها (lang): ${info.pageLang || 'غير محددة'} — اتجاه النص: ${info.pageDir || 'غير معروف'}
- عنوان الصفحة: ${info.title || 'غير متوفر'}
- حالة HTTP: ${info.status ?? 'غير متوفر'}
- وقت التحميل: ${info.loadMs} ملّي ثانية
- أخطاء رُصدت في المتصفح: ${info.errors.length ? info.errors.slice(0, 12).join(' | ') : 'لا يوجد'}

أجب بهذا الترتيب:
1. ماذا يظهر في الصفحة؟
2. هل توجد أخطاء واضحة؟
3. هل التصميم يعمل جيداً على هذا الجهاز؟ (ابحث عن نص مقصوص، تمرير أفقي، أزرار صغيرة، عناصر متراكبة)
   وهل لغة المحتوى واتجاهه مناسبان للدولة المحاكاة؟
4. هل توجد عناصر مفقودة أو مكسورة (صور، خطوط، أقسام فارغة)؟
5. الملخص والحكم النهائي: (سليم / تحذير / مشكلة) مع جملة واحدة.`;
  const body = {
    contents: [{ parts: [{ text: prompt }, { inlineData: { mimeType: 'image/jpeg', data: shotBuf.toString('base64') } }] }],
    generationConfig: { temperature: 0.2, maxOutputTokens: 900 }
  };
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': geminiKey },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(60000)
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Gemini ${res.status}: ${j?.error?.message || 'خطأ غير معروف'}`);
  const text = j?.candidates?.[0]?.content?.parts?.map((p) => p.text).filter(Boolean).join('\n');
  if (!text) throw new Error('رد Gemini فارغ (ربما حُجب المحتوى)');
  return text.trim();
}

async function analyzeSummary(run) {
  const data = { url: run.url, checks: run.done, ok: run.okCount, failed: run.failCount, byProfile: aggTable(run).slice(0, 40), topErrors: topErrors(run) };
  const prompt = `أنت مهندس جودة. هذه نتائج ${run.done} فحص لموقع يملكه المستخدم، موزعة على تركيبات (دولة · جهاز) مختلفة. حلّل الأرقام بالعربية وبإيجاز:
1. هل توجد مشاكل متقطعة أو مرتبطة بجهاز/لغة/دولة معينة؟ (قارن نسب الفشل والتحذيرات وp95 بين التركيبات)
2. أهم الأخطاء المتكررة وما الأرجح أنه سببها.
3. أهم 3 إجراءات للإصلاح مرتبة بالأولوية.
لا تخترع أرقاماً غير موجودة في البيانات.

${JSON.stringify(data)}`;
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': geminiKey },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.2, maxOutputTokens: 1200 } }),
    signal: AbortSignal.timeout(60000)
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(`Gemini ${res.status}: ${j?.error?.message || 'خطأ غير معروف'}`);
  const text = j?.candidates?.[0]?.content?.parts?.map((p) => p.text).filter(Boolean).join('\n');
  if (!text) throw new Error('رد Gemini فارغ');
  return text.trim();
}

// ---------- الفحص ----------
let browserPromise = null;
const getBrowser = () => {
  if (!browserPromise) {
    browserPromise = chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] }).catch((e) => { browserPromise = null; throw e; });
  }
  return browserPromise;
};

async function checkOnce(run, n) {
  const started = Date.now();
  const combo = run.combos[(n - 1) % run.combos.length];
  const dev = DEVICES[combo.device];
  const ctry = combo.country ? COUNTRIES[combo.country] : null;
  const profile = comboLabel(combo);
  const result = { light: !!run.light, n, time: nowISO(), ok: false, status: null, title: '', loadMs: null, errors: [], error: null, analysis: '', shot: false, profile, country: combo.country, device: combo.device, pageLang: '', pageDir: '' };
  let ctx;
  try {
    const browser = await getBrowser();
    const opts = {
      viewport: dev.viewport, deviceScaleFactor: dev.dsf, isMobile: dev.mobile, hasTouch: dev.touch,
      userAgent: dev.ua + UA_TAG
    };
    if (ctry) {
      opts.locale = ctry.locale;               // يضبط navigator.language وترويسة Accept-Language
      opts.timezoneId = ctry.tz;
      opts.geolocation = { latitude: ctry.geo[0], longitude: ctry.geo[1] };
      opts.permissions = ['geolocation'];
    }
    ctx = await browser.newContext(opts);      // سياق جديد كل فحص = جهاز جديد بدون كوكيز
    const page = await ctx.newPage();
    page.on('console', (m) => { if (m.type() === 'error') result.errors.push('console: ' + m.text().slice(0, 200)); });
    page.on('pageerror', (e) => result.errors.push('js: ' + String(e.message).slice(0, 200)));
    page.on('requestfailed', (r) => result.errors.push(`فشل طلب: ${r.url().slice(0, 120)} (${r.failure()?.errorText || ''})`));
    page.on('response', (r) => { if (r.status() >= 400) result.errors.push(`HTTP ${r.status()}: ${r.url().slice(0, 120)}`); });

    const resp = await page.goto(run.url, { waitUntil: 'load', timeout: 30000 });
    await page.waitForLoadState('networkidle', { timeout: run.light ? 3000 : 8000 }).catch(() => {});
    result.loadMs = Date.now() - started;
    result.status = resp ? resp.status() : null;
    result.title = await page.title().catch(() => '');
    result.ok = result.status !== null && result.status < 400;

    const diag = await page.evaluate(() => {
      const de = document.documentElement;
      return {
        lang: de.lang || '', dir: de.dir || getComputedStyle(de).direction,
        overflowX: de.scrollWidth - window.innerWidth,
        brokenImages: [...document.images].filter((i) => i.complete && i.naturalWidth === 0).length,
        height: Math.min(de.scrollHeight, 3000)
      };
    }).catch(() => ({ lang: '', dir: '', overflowX: 0, brokenImages: 0, height: dev.viewport.height }));
    result.pageLang = diag.lang; result.pageDir = diag.dir;
    if (diag.overflowX > 2) result.errors.push(`تخطيط: الصفحة أعرض من الشاشة بمقدار ${diag.overflowX}px (تمرير أفقي) على ${dev.name}`);
    if (diag.brokenImages) result.errors.push(`تخطيط: ${diag.brokenImages} صورة لم تُحمَّل`);
    const problem = !result.ok || result.errors.length > 0;
    // في الوضع الواسع: لقطة + تحليل Gemini فقط عند وجود مشكلة وضمن حدود لتوفير التكلفة
    const wantShot = !run.light || (problem && run.shotBudget > 0);
    if (wantShot) {
      if (run.light) run.shotBudget--;
      const buf = await page.screenshot({ type: 'jpeg', quality: 70, scale: 'css', fullPage: true, clip: { x: 0, y: 0, width: dev.viewport.width, height: Math.max(diag.height, 300) } });
      await fs.writeFile(path.join(run.dir, `${n}.jpg`), buf);
      result.shot = true;
      if (!run.light || run.aiBudget > 0) {
        if (run.light) run.aiBudget--;
        try {
          result.analysis = await analyzeWithGemini(buf, { url: run.url, profile, pageLang: diag.lang, pageDir: diag.dir, title: result.title, status: result.status, loadMs: result.loadMs, errors: result.errors });
        } catch (e) {
          result.analysis = 'تعذّر تحليل Gemini: ' + e.message;
          log(run, 'warn', `فحص #${n}: ${result.analysis}`);
        }
      }
    }
  } catch (e) {
    result.ok = false;
    result.error = String(e.message || e).split('\n')[0].slice(0, 300);
    result.loadMs = Date.now() - started;
  } finally {
    await ctx?.close().catch(() => {});
  }
  result.errors = [...new Set(result.errors)].slice(0, 25);
  return result;
}

function sleep(run, ms) {
  return new Promise((resolve) => {
    const t = setTimeout(resolve, ms);
    run.wake = () => { clearTimeout(t); resolve(); };
  });
}

async function runLoop(run) {
  log(run, 'info', run.total === 0 ? 'بدأت المراقبة (وضع لا نهائي حتى الإيقاف)' : `بدأت المراقبة (${run.total} فحص)`);
  let n = 0;
  while (!run.stop && (run.total === 0 || n < run.total)) {
    n++;
    log(run, 'info', `فحص #${n}: جارٍ فتح الموقع (${comboLabel(run.combos[(n - 1) % run.combos.length])})...`);
    const r = await checkOnce(run, n);
    run.done = n;
    r.ok ? run.okCount++ : run.failCount++;
    run.results.push(r);
    recordAgg(run, r);
    if (run.results.length > MAX_KEEP) {
      const old = run.results.shift();
      if (old.shot) fs.unlink(path.join(run.dir, `${old.n}.jpg`)).catch(() => {});
    }
    emit(run, 'result', r);
    emit(run, 'status', snapshot(run));
    if (r.ok) log(run, 'info', `فحص #${n} [${r.profile}]: نجح — HTTP ${r.status} — ${r.loadMs}ms`);
    else log(run, 'error', `فحص #${n} [${r.profile}]: فشل — ${r.error || 'HTTP ' + r.status}`);
    if (run.stop) break;
    if (run.total === 0 || n < run.total) await sleep(run, run.delayMs);
  }
  run.finishedAt = nowISO();
  if (run.light && geminiKey && run.done > 0) {
    try { run.finalAnalysis = await analyzeSummary(run); } catch (e) { run.finalAnalysis = 'تعذّر إنشاء الملخص: ' + e.message; }
  }
  run.status = run.stop ? 'stopped' : 'finished';
  log(run, 'info', run.stop ? 'تم إيقاف المراقبة' : 'اكتملت جميع الفحوصات');
  emit(run, 'status', snapshot(run));
}

// ---------- التقرير ----------
async function buildReport(run) {
  const rows = [];
  for (const r of run.results) {
    let img = '';
    if (r.shot) {
      const b = await fs.readFile(path.join(run.dir, `${r.n}.jpg`)).catch(() => null);
      if (b) img = `<img src="data:image/jpeg;base64,${b.toString('base64')}" alt="Screenshot ${r.n}">`;
    }
    rows.push(`<section class="c ${r.ok ? 'ok' : 'bad'}">
<h2>فحص #${r.n} — ${r.ok ? 'يعمل' : 'مشكلة'} — ${esc(r.profile)}</h2>
<p class="m">${esc(new Date(r.time).toLocaleString('ar'))} · HTTP ${esc(r.status ?? '—')} · ${esc(r.loadMs ?? '—')}ms · ${esc(r.title || 'بدون عنوان')} · lang=${esc(r.pageLang || '—')}</p>
${r.error ? `<p class="e">الخطأ: ${esc(r.error)}</p>` : ''}
${r.errors.length ? `<details open><summary>أخطاء مرصودة (${r.errors.length})</summary><ul>${r.errors.map((e) => `<li>${esc(e)}</li>`).join('')}</ul></details>` : ''}
${img}
${r.analysis ? `<h3>تحليل Gemini</h3><pre>${esc(r.analysis)}</pre>` : ''}
</section>`);
  }
  const logs = run.logs.map((l) => `<li class="${l.level}"><time>${esc(new Date(l.t).toLocaleTimeString('ar'))}</time> ${esc(l.msg)}</li>`).join('');
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>تقرير Website AI Monitor</title>
<style>body{font-family:Tahoma,Arial,sans-serif;background:#f4f6f8;color:#16202b;margin:0;padding:24px;line-height:1.7}
main{max-width:980px;margin:auto}h1{margin:0 0 4px}.m{color:#5b6875;margin:.2rem 0}
.sum{background:#fff;border-radius:12px;padding:16px;margin:16px 0;display:flex;gap:24px;flex-wrap:wrap}
.c{background:#fff;border-radius:12px;padding:16px;margin:16px 0;border-inline-start:6px solid #1a9e6b}.c.bad{border-color:#d43f3f}
img{max-width:100%;border:1px solid #dde3e9;border-radius:8px;margin:8px 0}pre{white-space:pre-wrap;background:#f0f3f6;padding:12px;border-radius:8px}
.e{color:#b02a2a;font-weight:700}li.error{color:#b02a2a}li.warn{color:#9a6a00}time{color:#5b6875;margin-inline-end:8px}h2{margin:0;font-size:1.1rem}</style></head><body><main>
<h1>تقرير Website AI Monitor</h1>
<p class="m">${esc(run.url)}</p>
<div class="sum"><div>عدد الفحوصات: <b>${run.done}</b></div><div>ناجحة: <b>${run.okCount}</b></div><div>فاشلة: <b>${run.failCount}</b></div>
<div>الفاصل: <b>${run.delayMs / 1000}ث</b></div><div>بدأ: <b>${esc(new Date(run.startedAt).toLocaleString('ar'))}</b></div></div>
${run.light ? `<h2>ملخص حسب الدولة والجهاز</h2><table border="1" cellpadding="6" style="border-collapse:collapse;background:#fff"><tr><th>التركيبة</th><th>فحوص</th><th>ناجحة</th><th>فاشلة</th><th>تحذيرات</th><th>متوسط ms</th><th>p95 ms</th></tr>${aggTable(run).map((a) => `<tr><td>${esc(a.profile)}</td><td>${a.n}</td><td>${a.ok}</td><td>${a.fail}</td><td>${a.warn}</td><td>${a.avg ?? '—'}</td><td>${a.p95 ?? '—'}</td></tr>`).join('')}</table><h3>أكثر الأخطاء تكراراً</h3><ol>${topErrors(run).map((e) => `<li>${esc(e.msg)} — <b>${e.count}</b></li>`).join('')}</ol>${run.finalAnalysis ? `<h3>تحليل Gemini</h3><pre>${esc(run.finalAnalysis)}</pre>` : ''}` : ''}
${rows.join('\n')}
<h2>السجل الزمني</h2><ul>${logs}</ul></main></body></html>`;
}

// ---------- الخادم ----------
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '20kb' }));

app.use((req, res, next) => {
  if (CORS_ORIGIN) {
    res.set('Access-Control-Allow-Origin', CORS_ORIGIN);
    res.set('Access-Control-Allow-Headers', 'Content-Type, x-app-password');
    res.set('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
  }
  next();
});

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/profiles', (req, res) => res.json({
  countries: Object.entries(COUNTRIES).map(([k, v]) => ({ key: k, name: v.name, locale: v.locale })),
  devices: Object.entries(DEVICES).map(([k, v]) => ({ key: k, name: v.name, width: v.viewport.width }))
}));

app.get('/api/config', auth, (req, res) => res.json({
  hasKey: !!geminiKey, keySource, model: GEMINI_MODEL, minDelay: MIN_DELAY, maxKeep: MAX_KEEP, authRequired: !!APP_PASSWORD
}));

app.post('/api/settings/key', auth, (req, res) => {
  const k = String(req.body?.key || '').trim();
  if (k.length < 20 || /\s/.test(k)) return res.status(400).json({ error: 'المفتاح غير صالح' });
  geminiKey = k; keySource = 'session';
  res.json({ ok: true });
});
app.delete('/api/settings/key', auth, (req, res) => {
  geminiKey = process.env.GEMINI_API_KEY || ''; keySource = geminiKey ? 'env' : 'none';
  res.json({ ok: true });
});

app.post('/api/runs', auth, async (req, res) => {
  try {
    const { url, count, delaySec, confirmOwner, countries, devices, coverAll, light } = req.body || {};
    if (confirmOwner !== true) return res.status(400).json({ error: 'يجب تأكيد أنك تملك الموقع أو لديك إذن باختباره' });
    if ([...runs.values()].filter((r) => r.status === 'running').length >= MAX_RUNS) return res.status(429).json({ error: `الحد الأقصى ${MAX_RUNS} عمليات متزامنة` });
    const target = await validateTarget(String(url || '').trim());
    const combos = buildCombos(Array.isArray(countries) ? countries : [], Array.isArray(devices) ? devices : []);
    const total = coverAll === true ? combos.length : Math.floor(Number(count));
    if (!Number.isFinite(total) || total < 0 || total > 100000) return res.status(400).json({ error: 'عدد الفحوصات غير صالح (0 = لا نهائي)' });
    const delay = Math.max(MIN_DELAY, Number(delaySec) || MIN_DELAY);
    const id = crypto.randomBytes(6).toString('hex');
    const dir = path.join(DATA_DIR, id);
    await fs.mkdir(dir, { recursive: true });
    const run = { id, url: target, total, combos, light: light === true, shotBudget: 30, aiBudget: 10, agg: new Map(), errCounts: new Map(), finalAnalysis: '', delayMs: delay * 1000, status: 'running', done: 0, okCount: 0, failCount: 0, results: [], logs: [], clients: new Set(), stop: false, wake: null, dir, startedAt: nowISO() };
    runs.set(id, run);
    runLoop(run).catch((e) => { run.status = 'stopped'; log(run, 'error', 'خطأ داخلي: ' + e.message); emit(run, 'status', snapshot(run)); });
    res.json({ id });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

const getRun = (req, res) => { const r = runs.get(req.params.id); if (!r) res.status(404).json({ error: 'العملية غير موجودة' }); return r; };

app.post('/api/runs/:id/stop', auth, (req, res) => {
  const run = getRun(req, res); if (!run) return;
  run.stop = true; run.wake?.();
  res.json({ ok: true });
});

app.get('/api/runs/:id/stream', auth, (req, res) => {
  const run = getRun(req, res); if (!run) return;
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.flushHeaders();
  res.write(`event: init\ndata: ${JSON.stringify({ ...snapshot(run), results: run.results, logs: run.logs })}\n\n`);
  run.clients.add(res);
  const ping = setInterval(() => res.write(': ping\n\n'), 20000);
  req.on('close', () => { clearInterval(ping); run.clients.delete(res); });
});

app.get('/api/runs/:id/shot/:n', auth, (req, res) => {
  const run = getRun(req, res); if (!run) return;
  const n = Number(req.params.n);
  if (!Number.isInteger(n)) return res.sendStatus(400);
  res.set('Cache-Control', 'private, max-age=3600');
  res.sendFile(path.join(run.dir, `${n}.jpg`), (e) => { if (e && !res.headersSent) res.sendStatus(404); });
});

app.get('/api/runs/:id/report', auth, async (req, res) => {
  const run = getRun(req, res); if (!run) return;
  const html = await buildReport(run);
  res.set({ 'Content-Type': 'text/html; charset=utf-8', 'Content-Disposition': `attachment; filename="monitor-report-${run.id}.html"` });
  res.send(html);
});

const server = app.listen(PORT, () => {
  console.log(`Website AI Monitor يعمل على http://localhost:${PORT}`);
  if (!APP_PASSWORD) console.log('تنبيه: لم يتم تعيين APP_PASSWORD — لا تنشر المشروع علناً بدون كلمة مرور.');
  if (!geminiKey) console.log('تنبيه: GEMINI_API_KEY غير معيّن — يمكنك إدخاله من الإعدادات.');
});

async function shutdown() {
  for (const r of runs.values()) { r.stop = true; r.wake?.(); }
  server.close();
  (await browserPromise?.catch(() => null))?.close().catch(() => {});
  setTimeout(() => process.exit(0), 500);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
