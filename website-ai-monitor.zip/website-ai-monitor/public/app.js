(() => {
  const $ = (s) => document.querySelector(s);
  const BASE = (localStorage.getItem('apiBase') || window.API_BASE || '').replace(/\/$/, '');
  let token = localStorage.getItem('appToken') || '';
  let runId = null, es = null, total = 0, loads = [];
  const MAX_CARDS = 60;

  const el = {
    url: $('#url'), count: $('#count'), delay: $('#delay'), owner: $('#owner'), msg: $('#msg'),
    start: $('#btnStart'), stop: $('#btnStop'), exp: $('#btnExport'),
    results: $('#results'), log: $('#log'), pulse: $('#pulse'), bar: document.querySelector('.bar'), fill: $('#barFill'),
    sProgress: $('#sProgress'), sOk: $('#sOk'), sFail: $('#sFail'), sAvg: $('#sAvg'), sState: $('#sState'),
    chips: [...document.querySelectorAll('#chips button')]
  };

  // ---------- مساعدات ----------
  const qs = () => (token ? `token=${encodeURIComponent(token)}` : '');
  async function api(path, opts = {}) {
    const r = await fetch(BASE + path, { ...opts, headers: { 'Content-Type': 'application/json', ...(token ? { 'x-app-password': token } : {}), ...(opts.headers || {}) } });
    const j = await r.json().catch(() => ({}));
    if (r.status === 401) { openSettings(); throw new Error(j.error || 'كلمة المرور مطلوبة — أدخلها في الإعدادات'); }
    if (!r.ok) throw new Error(j.error || `خطأ HTTP ${r.status}`);
    return j;
  }
  const say = (t, good) => { el.msg.textContent = t || ''; el.msg.className = 'msg' + (good ? ' good' : ''); };
  const fmtTime = (iso) => new Date(iso).toLocaleTimeString('ar-EG-u-nu-latn', { hour12: false });
  const fmtDT = (iso) => new Date(iso).toLocaleString('ar-EG-u-nu-latn');

  // ---------- اختيار العدد ----------
  let infinite = false;
  function setCount(n) {
    infinite = n === 0;
    el.count.disabled = infinite;
    if (!infinite) el.count.value = n;
    el.chips.forEach((b) => b.classList.toggle('on', Number(b.dataset.n) === n));
    total = infinite ? 0 : n;
  }
  el.chips.forEach((b) => b.addEventListener('click', () => setCount(Number(b.dataset.n))));
  el.count.addEventListener('input', () => {
    const n = Number(el.count.value);
    el.chips.forEach((b) => b.classList.toggle('on', Number(b.dataset.n) === n));
  });
  setCount(10);

  // ---------- الحالة ----------
  function setState(s) {
    const map = { running: ['run', 'يعمل'], finished: ['done', 'اكتمل'], stopped: ['stop', 'متوقف'], idle: ['idle', 'جاهز'] };
    const [cls, label] = map[s] || map.idle;
    el.sState.className = 'badge ' + cls; el.sState.textContent = label;
    const running = s === 'running';
    el.pulse.classList.toggle('live', running);
    el.start.disabled = running; el.stop.disabled = !running;
    el.exp.disabled = !runId;
    el.bar.classList.toggle('inf', running && total === 0);
  }
  function updateStats(s) {
    total = s.total;
    el.sProgress.textContent = total === 0 ? `${s.done} / ∞` : `${s.done} / ${total}`;
    el.sOk.textContent = s.ok; el.sFail.textContent = s.failed;
    if (total > 0) el.fill.style.width = Math.min(100, (s.done / total) * 100) + '%';
    else if (s.status !== 'running') el.fill.style.width = '0';
    setState(s.status);
  }
  function updateAvg() {
    el.sAvg.textContent = loads.length ? Math.round(loads.reduce((a, b) => a + b, 0) / loads.length) + ' ms' : '—';
  }

  // ---------- عرض ----------
  function addLog(l) {
    el.log.querySelector('.empty')?.remove();
    const li = document.createElement('li');
    li.className = l.level;
    const t = document.createElement('time'); t.textContent = fmtTime(l.t);
    const s = document.createElement('span'); s.textContent = l.msg;
    li.append(t, s);
    el.log.prepend(li);
    while (el.log.children.length > 200) el.log.lastChild.remove();
  }

  function addResult(r) {
    el.results.querySelector('.empty')?.remove();
    if (r.loadMs != null && r.ok) loads.push(r.loadMs);
    updateAvg();
    const card = document.createElement('article');
    card.className = 'card' + (r.ok ? '' : ' bad');

    const head = document.createElement('header');
    const h = document.createElement('h3'); h.textContent = `فحص #${r.n}`;
    const tag = document.createElement('span');
    tag.className = 'tag ' + (r.ok ? 'ok' : 'bad');
    tag.textContent = r.ok ? 'الموقع يعمل' : (r.error ? 'الموقع لا يفتح' : 'خطأ في الاستجابة');
    head.append(h, tag);

    const meta = document.createElement('div'); meta.className = 'meta';
    [fmtDT(r.time), `HTTP ${r.status ?? '—'}`, `${r.loadMs ?? '—'} ms`, r.title || 'بدون عنوان'].forEach((t) => {
      const s = document.createElement('span'); s.textContent = t; meta.append(s);
    });
    card.append(head, meta);

    if (r.error) {
      const e = document.createElement('div'); e.className = 'errs'; e.textContent = r.error; card.append(e);
    }
    if (r.errors?.length) {
      const e = document.createElement('div'); e.className = 'errs';
      r.errors.forEach((x) => { const d = document.createElement('div'); d.textContent = x; e.append(d); });
      card.append(e);
    }
    if (r.shot) {
      const img = document.createElement('img');
      img.loading = 'lazy'; img.alt = `لقطة شاشة للفحص ${r.n}`;
      img.src = `${BASE}/api/runs/${runId}/shot/${r.n}${qs() ? '?' + qs() : ''}`;
      img.addEventListener('click', () => img.classList.toggle('open'));
      card.append(img);
    }
    if (r.analysis) {
      const ai = document.createElement('div'); ai.className = 'ai';
      const b = document.createElement('b'); b.textContent = 'تحليل Gemini';
      ai.append(b, document.createTextNode(r.analysis));
      card.append(ai);
    }
    el.results.prepend(card);
    while (el.results.children.length > MAX_CARDS) el.results.lastChild.remove();
  }

  // ---------- البث المباشر ----------
  function connect(id) {
    es?.close();
    es = new EventSource(`${BASE}/api/runs/${id}/stream${qs() ? '?' + qs() : ''}`);
    es.addEventListener('init', (e) => {
      const d = JSON.parse(e.data);
      el.results.innerHTML = ''; el.log.innerHTML = ''; loads = [];
      d.logs.forEach(addLog); d.results.forEach(addResult); updateStats(d);
    });
    es.addEventListener('result', (e) => addResult(JSON.parse(e.data)));
    es.addEventListener('log', (e) => addLog(JSON.parse(e.data)));
    es.addEventListener('status', (e) => {
      const s = JSON.parse(e.data); updateStats(s);
      if (s.status !== 'running') { es.close(); es = null; }
    });
    es.onerror = () => { /* المتصفح يعيد الاتصال تلقائياً */ };
  }

  // ---------- الأزرار ----------
  el.start.addEventListener('click', async () => {
    say('');
    const url = el.url.value.trim();
    if (!url) return say('أدخل رابط الموقع أولاً.');
    if (!el.owner.checked) return say('يجب تأكيد ملكيتك للموقع أو إذنك باختباره.');
    const count = infinite ? 0 : Number(el.count.value);
    if (!infinite && (!count || count < 1)) return say('أدخل عدد فحوصات صحيحاً.');
    el.start.disabled = true;
    try {
      const { id } = await api('/api/runs', { method: 'POST', body: JSON.stringify({ url, count, delaySec: Number(el.delay.value), confirmOwner: true }) });
      runId = id; total = count; loads = [];
      el.results.innerHTML = ''; el.log.innerHTML = '';
      setState('running'); connect(id);
    } catch (e) { say(e.message); el.start.disabled = false; }
  });

  el.stop.addEventListener('click', async () => {
    el.stop.disabled = true;
    try { await api(`/api/runs/${runId}/stop`, { method: 'POST' }); say('جارٍ الإيقاف بعد إنهاء الفحص الحالي...', true); }
    catch (e) { say(e.message); el.stop.disabled = false; }
  });

  el.exp.addEventListener('click', async () => {
    try {
      const r = await fetch(`${BASE}/api/runs/${runId}/report`, { headers: token ? { 'x-app-password': token } : {} });
      if (!r.ok) throw new Error('تعذر إنشاء التقرير');
      const blob = await r.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = `monitor-report-${runId}.html`; a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
    } catch (e) { say(e.message); }
  });

  // ---------- الإعدادات ----------
  const dlg = $('#dlg'), dlgMsg = $('#dlgMsg');
  async function refreshKeyState() {
    try {
      const c = await api('/api/config');
      $('#keyState').textContent = c.hasKey ? `مفتاح Gemini مُعيّن (المصدر: ${c.keySource === 'env' ? 'ملف .env' : 'الجلسة'}) — النموذج: ${c.model}` : 'لا يوجد مفتاح Gemini. أدخله هنا أو في ملف .env.';
      el.delay.min = c.minDelay; $('#delayHint').textContent = `الحد الأدنى ${c.minDelay} ثوانٍ لتفادي الطلبات المتتالية.`;
      if (Number(el.delay.value) < c.minDelay) el.delay.value = c.minDelay;
    } catch (e) { $('#keyState').textContent = e.message; }
  }
  function openSettings() {
    $('#apiBase').value = localStorage.getItem('apiBase') || '';
    $('#appPass').value = token; $('#apiKey').value = ''; dlgMsg.textContent = '';
    if (!dlg.open) dlg.showModal();
    refreshKeyState();
  }
  $('#btnSettings').addEventListener('click', openSettings);
  $('#btnSave').addEventListener('click', async () => {
    dlgMsg.className = 'msg';
    const base = $('#apiBase').value.trim();
    base ? localStorage.setItem('apiBase', base) : localStorage.removeItem('apiBase');
    token = $('#appPass').value; token ? localStorage.setItem('appToken', token) : localStorage.removeItem('appToken');
    const key = $('#apiKey').value.trim();
    try {
      if (key) await api('/api/settings/key', { method: 'POST', body: JSON.stringify({ key }) });
      dlgMsg.className = 'msg good'; dlgMsg.textContent = 'تم الحفظ.';
      $('#apiKey').value = ''; refreshKeyState();
      if (base !== BASE) dlgMsg.textContent += ' أعد تحميل الصفحة لتطبيق عنوان الخادم.';
    } catch (e) { dlgMsg.textContent = e.message; }
  });
  $('#btnClearKey').addEventListener('click', async () => {
    try { await api('/api/settings/key', { method: 'DELETE' }); dlgMsg.className = 'msg good'; dlgMsg.textContent = 'أُزيل مفتاح الجلسة.'; refreshKeyState(); }
    catch (e) { dlgMsg.className = 'msg'; dlgMsg.textContent = e.message; }
  });

  setState('idle');
  refreshKeyState();
})();
